参考文档：
[git常用命令速查表](https://www.w3cschool.cn/git/git-cheat-sheet.html)


git clone 
git add .
git commit -m ""
git merge
git push
git pull
